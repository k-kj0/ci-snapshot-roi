export type RunnerSize = "2x" | "4x" | "8x" | "16x" | "32x";
export type Platform = "ubuntu-x64" | "ubuntu-arm64" | "windows" | "macos" | "byoc";
const PRICES: Record<"ubuntu-x64" | "ubuntu-arm64", Record<RunnerSize, number>> = {
  "ubuntu-x64": { "2x": 0.004, "4x": 0.008, "8x": 0.016, "16x": 0.032, "32x": 0.064 },
  "ubuntu-arm64": { "2x": 0.003, "4x": 0.006, "8x": 0.012, "16x": 0.024, "32x": 0.048 }
};
export const RESTORE_COST_PER_JOB = 0.04;
export const STORAGE_COST_PER_SNAPSHOT_HOUR = 0.025;
export type Inputs = { platform: Platform; size: RunnerSize; jobsPerMonth: number; coldRuntimeMinutes: number; setupMinutesSaved: number; snapshotBootMinutes: number; activeSnapshots: number; storageHoursPerSnapshot: number };
export type Estimate = { supported: boolean; runnerRate: number; baselineRunnerCost: number; snapshotRunnerCost: number; restoreCost: number; storageCost: number; snapshotTotal: number; monthlySavings: number; savingsPercent: number; breakEvenSetupMinutes: number; recommendation: "use" | "avoid" | "inconclusive"; explanation: string };
export function estimateROI(input: Inputs): Estimate {
  const supported = input.platform === "ubuntu-x64" || input.platform === "ubuntu-arm64";
  const runnerRate = supported ? PRICES[input.platform][input.size] : 0;
  const jobs = Math.max(0, input.jobsPerMonth);
  const baselineRunnerCost = jobs * Math.max(0, input.coldRuntimeMinutes) * runnerRate;
  const netMinutes = Math.max(0, input.coldRuntimeMinutes - input.setupMinutesSaved + input.snapshotBootMinutes);
  const snapshotRunnerCost = jobs * netMinutes * runnerRate;
  const restoreCost = jobs * RESTORE_COST_PER_JOB;
  const storageCost = Math.max(0, input.activeSnapshots) * Math.max(0, input.storageHoursPerSnapshot) * STORAGE_COST_PER_SNAPSHOT_HOUR;
  const snapshotTotal = snapshotRunnerCost + restoreCost + storageCost;
  const monthlySavings = baselineRunnerCost - snapshotTotal;
  const savingsPercent = baselineRunnerCost > 0 ? monthlySavings / baselineRunnerCost * 100 : 0;
  const breakEvenSetupMinutes = runnerRate > 0 ? RESTORE_COST_PER_JOB / runnerRate + storageCost / Math.max(1, jobs * runnerRate) + input.snapshotBootMinutes : 0;
  let recommendation: Estimate["recommendation"] = "inconclusive";
  let explanation = "Add realistic workflow measurements to get a useful estimate.";
  if (!supported) explanation = "Snapshots are supported on WarpBuild Cloud Ubuntu x64 and ARM64 runners only. Do not configure snapshots for this platform.";
  else if (jobs > 0 && monthlySavings > 0) { recommendation = "use"; explanation = "Under these assumptions, estimated runner-time savings exceed restore and storage charges."; }
  else if (jobs > 0 && monthlySavings <= 0) { recommendation = "avoid"; explanation = "Under these assumptions, restore and storage charges outweigh estimated runner-time savings."; }
  return { supported, runnerRate, baselineRunnerCost, snapshotRunnerCost, restoreCost, storageCost, snapshotTotal, monthlySavings, savingsPercent, breakEvenSetupMinutes, recommendation, explanation };
}
export function money(value: number): string { return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(value); }
